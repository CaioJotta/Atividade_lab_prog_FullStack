const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
const User = require('./models/user');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

// Sincronize o modelo com o banco de dados
sequelize.sync()
    .then(() => console.log('Database synced'))
    .catch(err => console.log('Error syncing database:', err));

// Middleware para autenticação
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Endpoint de teste autenticado
app.get('/test', authenticateToken, (req, res) => {
    res.send('Authenticated successfully');
});

// Cadastro de usuário
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({ username, email, password: hashedPassword });
        res.status(201).json({ id: user.id, username, email });
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


// Login de usuário
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        // Verifique se o usuário existe
        const user = await User.findOne({ where: { email } });
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Verifique a senha
        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Gere um token JWT
        const token = jwt.sign(
            { id: user.id, email: user.email },
            process.env.JWT_SECRET,
            { expiresIn: '1h' } // Token expira em 1 hora
        );

        // Retorne o token para o usuário
        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


// Atualização de usuário
app.put('/users/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { username, email, password } = req.body;

    let query = 'UPDATE users SET username = COALESCE(?, username), email = COALESCE(?, email), password = COALESCE(?, password) WHERE id = ?';
    let values = [username, email, password ? bcrypt.hashSync(password, 10) : undefined, id];

    db.query(query, values, (error, results) => {
        if (error) return res.status(500).json({ error: 'Internal Server Error' });
        res.json({ id, username, email });
    });
});

// Deleção de usuário
app.delete('/users/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM users WHERE id = ?', [id], (error, results) => {
        if (error) return res.status(500).json({ error: 'Internal Server Error' });
        res.status(204).end();
    });
});

// Listagem de usuários
app.get('/users', authenticateToken, (req, res) => {
    db.query('SELECT id, username, email FROM users', (error, results) => {
        if (error) return res.status(500).json({ error: 'Internal Server Error' });
        res.json(results);
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
